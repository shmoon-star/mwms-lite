import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { notifyAsnCreatedFromPackingList } from "@/lib/notify";

export const dynamic = "force-dynamic";

function buildAsnNo() {
  return `ASN-${Date.now()}`;
}

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const sb = await createClient();
    const now = new Date().toISOString();

    // 1) Packing List Header
    const { data: plHeader, error: plHeaderError } = await sb
      .from("packing_list_header")
      .select(
        `
          id,
          packing_list_no,
          vendor_id,
          status,
          asn_id,
          asn_created,
          vendors (
            id,
            vendor_name,
            email
          )
        `
      )
      .eq("id", id)
      .single();

    if (plHeaderError || !plHeader) {
      return NextResponse.json(
        { ok: false, error: "Packing List not found" },
        { status: 404 }
      );
    }

    const allowedStatuses = ["FINALIZED", "SUBMITTED"];
    if (!allowedStatuses.includes(String(plHeader.status || "").toUpperCase())) {
      return NextResponse.json(
        {
          ok: false,
          error: "Packing List must be FINALIZED or SUBMITTED",
        },
        { status: 400 }
      );
    }

    // 2) Already exists?
    const { data: existingAsn, error: existingAsnError } = await sb
      .from("asn_header")
      .select("id, asn_no, status")
      .eq("source_type", "PACKING_LIST")
      .eq("source_id", plHeader.id)
      .maybeSingle();

    if (existingAsnError) {
      return NextResponse.json(
        { ok: false, error: existingAsnError.message },
        { status: 500 }
      );
    }

    if (existingAsn) {
      return NextResponse.json({
        ok: true,
        created: false,
        asn_id: existingAsn.id,
        asn_no: existingAsn.asn_no,
        status: existingAsn.status,
      });
    }

    // 3) Packing List Lines
    const { data: plLines, error: plLinesError } = await sb
      .from("packing_list_lines")
      .select("id, line_no, sku, qty")
      .eq("packing_list_id", plHeader.id)
      .order("id", { ascending: true });

    if (plLinesError) {
      return NextResponse.json(
        { ok: false, error: plLinesError.message },
        { status: 500 }
      );
    }

    if (!plLines || plLines.length === 0) {
      return NextResponse.json(
        { ok: false, error: "Packing List has no lines" },
        { status: 400 }
      );
    }

    // 4) ASN Header Insert
    const asnNo = buildAsnNo();

    const { data: insertedAsn, error: asnInsertError } = await sb
      .from("asn_header")
      .insert({
        asn_no: asnNo,
        vendor_id: plHeader.vendor_id,
        source_type: "PACKING_LIST",
        source_id: plHeader.id,
        status: "OPEN",
        created_at: now,
        updated_at: now,
      })
      .select("id, asn_no")
      .single();

    if (asnInsertError || !insertedAsn) {
      return NextResponse.json(
        {
          ok: false,
          error: asnInsertError?.message || "Failed to create ASN header",
        },
        { status: 500 }
      );
    }

    // 5) ASN Lines Insert
    const rows = plLines.map((line) => ({
      asn_id: insertedAsn.id,
      line_no: Number(line.line_no || 0),
      sku: line.sku,
      qty_expected: Number(line.qty || 0),
      created_at: now,
      updated_at: now,
    }));

    const { error: lineInsertError } = await sb.from("asn_lines").insert(rows);

    if (lineInsertError) {
      return NextResponse.json(
        { ok: false, error: lineInsertError.message },
        { status: 500 }
      );
    }

    // 6) Packing List back-fill
    const { error: plUpdateError } = await sb
      .from("packing_list_header")
      .update({
        asn_created: true,
        asn_id: insertedAsn.id,
        updated_at: now,
      })
      .eq("id", plHeader.id);

    if (plUpdateError) {
      return NextResponse.json(
        { ok: false, error: plUpdateError.message },
        { status: 500 }
      );
    }

    // 7) Optional mail notify (실패해도 본 기능 성공 처리)
    try {
      const vendorObj = Array.isArray(plHeader.vendors)
        ? plHeader.vendors[0]
        : plHeader.vendors;

      const vendorName = vendorObj?.vendor_name || null;
      const vendorEmail = vendorObj?.email || null;

      await notifyAsnCreatedFromPackingList({
        packingListNo: plHeader.packing_list_no || String(plHeader.id),
        asnNo: insertedAsn.asn_no,
        vendorName,
        to: vendorEmail ? [vendorEmail] : [],
      });
    } catch (mailError) {
      console.error("[ASN_FROM_PL] notify failed:", mailError);
    }

    return NextResponse.json({
      ok: true,
      created: true,
      asn_id: insertedAsn.id,
      asn_no: insertedAsn.asn_no,
    });
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e?.message || "Unknown error" },
      { status: 500 }
    );
  }
}