type SendMailParams = {
  to: string | string[];
  subject: string;
  html: string;
};

function normalizeRecipients(to: string | string[]) {
  if (Array.isArray(to)) {
    return to.map((v) => String(v).trim()).filter(Boolean);
  }
  return String(to)
    .split(",")
    .map((v) => v.trim())
    .filter(Boolean);
}

/**
 * 현재는 stub.
 * 나중에 resend / nodemailer / 사내 SMTP로 교체하면 됨.
 */
export async function sendMail({ to, subject, html }: SendMailParams) {
  const recipients = normalizeRecipients(to);

  if (recipients.length === 0) {
    console.log("[MAIL:SKIP] no recipients", { subject });
    return { ok: true, skipped: true };
  }

  console.log("[MAIL:STUB]", {
    to: recipients,
    subject,
    html,
  });

  return { ok: true, skipped: false };
}

export async function notifyPackingListSubmitted(params: {
  packingListNo: string;
  vendorName?: string | null;
  to: string | string[];
}) {
  return sendMail({
    to: params.to,
    subject: `[mwms-lite] Packing List submitted: ${params.packingListNo}`,
    html: `
      <div style="font-family: Arial, sans-serif; font-size: 14px; line-height: 1.6;">
        <p>Packing List submitted successfully.</p>
        <p><b>Packing List No:</b> ${params.packingListNo}</p>
        <p><b>Vendor:</b> ${params.vendorName || "-"}</p>
      </div>
    `,
  });
}

export async function notifyAsnCreatedFromPackingList(params: {
  packingListNo: string;
  asnNo: string;
  vendorName?: string | null;
  to: string | string[];
}) {
  return sendMail({
    to: params.to,
    subject: `[mwms-lite] ASN created from Packing List: ${params.asnNo}`,
    html: `
      <div style="font-family: Arial, sans-serif; font-size: 14px; line-height: 1.6;">
        <p>ASN created from Packing List.</p>
        <p><b>Packing List No:</b> ${params.packingListNo}</p>
        <p><b>ASN No:</b> ${params.asnNo}</p>
        <p><b>Vendor:</b> ${params.vendorName || "-"}</p>
      </div>
    `,
  });
}

export async function notifyGrConfirmed(params: {
  grNo: string;
  asnNo?: string | null;
  vendorName?: string | null;
  to: string | string[];
}) {
  return sendMail({
    to: params.to,
    subject: `[mwms-lite] GR confirmed: ${params.grNo}`,
    html: `
      <div style="font-family: Arial, sans-serif; font-size: 14px; line-height: 1.6;">
        <p>GR confirmed successfully.</p>
        <p><b>GR No:</b> ${params.grNo}</p>
        <p><b>ASN No:</b> ${params.asnNo || "-"}</p>
        <p><b>Vendor:</b> ${params.vendorName || "-"}</p>
      </div>
    `,
  });
}