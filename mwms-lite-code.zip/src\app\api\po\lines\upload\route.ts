import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

type Row = {
  po_no: string;
  sku: string;
  qty_ordered: number;
};

function parseCSV(text: string): Row[] {
  const lines = text
    .replace(/\r\n/g, "\n")
    .split("\n")
    .map((l) => l.trim())
    .filter(Boolean);

  if (lines.length < 2) return [];

  const header = lines[0].split(",").map((h) => h.trim().toLowerCase());

  const poIdx = header.indexOf("po_no");
  const skuIdx = header.indexOf("sku");
  const qtyIdx = header.indexOf("qty_ordered");

  if (poIdx === -1 || skuIdx === -1 || qtyIdx === -1) {
    throw new Error("CSV must include po_no, sku, qty_ordered");
  }

  const rows: Row[] = [];

  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(",").map((c) => c.trim());

    const po_no = cols[poIdx];
    const sku = cols[skuIdx];
    const qty_ordered = Number(cols[qtyIdx] || 0);

    if (!po_no || !sku) continue;

    rows.push({
      po_no,
      sku,
      qty_ordered,
    });
  }

  return rows;
}

export async function POST(req: Request) {
  try {
    const sb = await createClient();

    const formData = await req.formData();
    const file = formData.get("file");

    if (!file || !(file instanceof File)) {
      return NextResponse.json(
        { ok: false, error: "CSV file required" },
        { status: 400 }
      );
    }

    const text = await file.text();
    const parsed = parseCSV(text);

    const inserted: any[] = [];
    const updated: any[] = [];
    const errors: any[] = [];

    for (const row of parsed) {
      try {
        const { data: header } = await sb
          .from("po_header")
          .select("id")
          .eq("po_no", row.po_no)
          .single();

        if (!header) {
          throw new Error(`PO not found: ${row.po_no}`);
        }

        const { data: existing } = await sb
          .from("po_line")
          .select("id")
          .eq("po_id", header.id)
          .eq("sku", row.sku)
          .maybeSingle();

        if (existing) {
          const { error } = await sb
            .from("po_line")
            .update({
              qty_ordered: row.qty_ordered,
            })
            .eq("id", existing.id);

          if (error) throw error;

          updated.push({
            po_no: row.po_no,
            sku: row.sku,
          });
        } else {
          const { error } = await sb.from("po_line").insert({
            po_id: header.id,
            sku: row.sku,
            qty: 0,
            qty_ordered: row.qty_ordered,
          });

          if (error) throw error;

          inserted.push({
            po_no: row.po_no,
            sku: row.sku,
          });
        }
      } catch (e: any) {
        errors.push({
          po_no: row.po_no,
          sku: row.sku,
          error: e.message,
        });
      }
    }

    return NextResponse.json({
      ok: true,
      total_rows: parsed.length,
      inserted_count: inserted.length,
      updated_count: updated.length,
      error_count: errors.length,
      inserted,
      updated,
      errors,
    });
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e.message ?? String(e) },
      { status: 500 }
    );
  }
}