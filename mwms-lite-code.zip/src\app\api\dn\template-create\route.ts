import { buildCsvDownloadResponse } from "@/lib/csv-template";

export const dynamic = "force-dynamic";

export async function GET() {
  return buildCsvDownloadResponse({
    filename: "dn_create_template.csv",
    headers: ["sku", "qty"],
    rows: [
      ["SKU001", 10],
      ["SKU002", 5],
    ],
  });
}