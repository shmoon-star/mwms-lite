import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

type GrHeaderRow = {
  id: string;
  gr_no: string | null;
  status: string | null;
  created_at: string | null;
  confirmed_at: string | null;
  asn_id: string | null;
};

type AsnHeaderRow = {
  id: string;
  asn_no: string | null;
};

type GrLineRow = {
  id: string;
  gr_id: string;
  line_no: number | null;
  sku: string | null;
  qty_expected: number | null;
  qty_received: number | null;
};

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const sb = await createClient();

    const { data: header, error: headerError } = await sb
      .from("gr_header")
      .select("id, gr_no, status, created_at, confirmed_at, asn_id")
      .eq("id", id)
      .single();

    if (headerError || !header) {
      return NextResponse.json(
        { ok: false, error: "GR not found" },
        { status: 404 }
      );
    }

    const headerRow = header as GrHeaderRow;

    let asn: AsnHeaderRow | null = null;
    if (headerRow.asn_id) {
      const { data: asnRow, error: asnError } = await sb
        .from("asn_header")
        .select("id, asn_no")
        .eq("id", headerRow.asn_id)
        .maybeSingle();

      if (asnError) {
        return NextResponse.json(
          { ok: false, error: asnError.message },
          { status: 500 }
        );
      }

      asn = (asnRow as AsnHeaderRow | null) || null;
    }

    const { data: lines, error: lineError } = await sb
      .from("gr_line")
      .select("id, gr_id, line_no, sku, qty_expected, qty_received")
      .eq("gr_id", id)
      .order("created_at", { ascending: true });

    if (lineError) {
      return NextResponse.json(
        { ok: false, error: lineError.message },
        { status: 500 }
      );
    }

    const item = {
      id: headerRow.id,
      gr_no: headerRow.gr_no,
      status: headerRow.status,
      created_at: headerRow.created_at,
      confirmed_at: headerRow.confirmed_at,
      asn_id: headerRow.asn_id,
      asn_no: asn?.asn_no || null,
      vendor_name: null,
      lines: ((lines || []) as GrLineRow[]).map((line, idx) => ({
        id: line.id,
        line_no: Number(line.line_no || idx + 1),
        sku: line.sku,
        qty_expected: Number(line.qty_expected || 0),
        qty_received: Number(line.qty_received || 0),
      })),
    };

    return NextResponse.json({ ok: true, item });
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e?.message || "Unknown error" },
      { status: 500 }
    );
  }
}