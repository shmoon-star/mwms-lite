import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

type Ctx = {
  params: Promise<{ asnId: string }>;
};

function buildGrNo() {
  const now = new Date();
  return `GR-${now.getTime()}`;
}

export async function POST(_req: Request, ctx: Ctx) {
  try {
    const { asnId } = await ctx.params;
    const sb = await createClient();
    const now = new Date().toISOString();

    const { data: asnHeader, error: asnErr } = await sb
      .from("asn_header")
      .select("id, asn_no, status")
      .eq("id", asnId)
      .single();

    if (asnErr || !asnHeader) {
      return NextResponse.json(
        { ok: false, error: "ASN not found" },
        { status: 404 }
      );
    }

    const { data: asnLines, error: lineErr } = await sb
      .from("asn_line")
      .select("id, line_no, sku, qty_expected")
      .eq("asn_id", asnId)
      .order("line_no", { ascending: true });

    if (lineErr) {
      throw lineErr;
    }

    if (!asnLines || asnLines.length === 0) {
      return NextResponse.json(
        { ok: false, error: "No ASN lines" },
        { status: 400 }
      );
    }

    const { data: existing } = await sb
      .from("gr_header")
      .select("id, gr_no")
      .eq("asn_id", asnId)
      .maybeSingle();

    if (existing?.id) {
      return NextResponse.json({
        ok: true,
        created: false,
        message: "GR already exists",
        gr_id: existing.id,
        gr_no: existing.gr_no,
      });
    }

    const grNo = buildGrNo();

    const { data: grHeader, error: grHeaderErr } = await sb
      .from("gr_header")
      .insert({
        asn_id: asnId,
        gr_no: grNo,
        status: "PENDING",
        created_at: now,
      })
      .select("id, gr_no")
      .single();

    if (grHeaderErr || !grHeader) {
      throw grHeaderErr;
    }

    const grLines = asnLines.map((l, idx) => ({
      gr_id: grHeader.id,
      line_no: l.line_no ?? idx + 1,
      asn_line_id: l.id,
      sku: l.sku,
      qty: 0,
      qty_expected: Number(l.qty_expected ?? 0),
      qty_received: 0,
      created_at: now,
    }));

    const { error: grLineErr } = await sb
      .from("gr_line")
      .insert(grLines);

    if (grLineErr) {
      throw grLineErr;
    }

    return NextResponse.json({
      ok: true,
      created: true,
      gr_id: grHeader.id,
      gr_no: grHeader.gr_no,
    });
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e?.message ?? String(e) },
      { status: 500 }
    );
  }
}