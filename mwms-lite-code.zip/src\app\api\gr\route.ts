import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

function normalizeStatusParam(status: string) {
  const v = (status || "OPEN").trim().toUpperCase();
  if (["OPEN", "PENDING", "CONFIRMED", "ALL", "DRAFT"].includes(v)) return v;
  return "OPEN";
}

type GrHeaderRow = {
  id: string;
  gr_no: string | null;
  asn_id: string | null;
  status: string | null;
  created_at: string | null;
};

type AsnHeaderRow = {
  id: string;
  asn_no: string | null;
};

type GrLineRow = {
  gr_id: string;
  qty_expected: number | null;
  qty_received: number | null;
};

export async function GET(req: Request) {
  try {
    const sb = await createClient();
    const url = new URL(req.url);
    const status = normalizeStatusParam(url.searchParams.get("status") || "OPEN");

    let query = sb
      .from("gr_header")
      .select("id, gr_no, asn_id, status, created_at")
      .order("created_at", { ascending: false });

    if (status === "OPEN") {
      query = query.in("status", ["DRAFT", "PENDING", "OPEN"]);
    } else if (status !== "ALL") {
      query = query.eq("status", status);
    }

    const { data: headers, error: headerError } = await query;

    if (headerError) {
      return NextResponse.json(
        { ok: false, error: headerError.message },
        { status: 500 }
      );
    }

    const headerRows = (headers || []) as GrHeaderRow[];

    if (headerRows.length === 0) {
      return NextResponse.json({ ok: true, items: [] });
    }

    const grIds = headerRows.map((r) => r.id);
    const asnIds = [...new Set(headerRows.map((r) => r.asn_id).filter(Boolean))] as string[];

    const { data: lineRows, error: lineError } = await sb
      .from("gr_line")
      .select("gr_id, qty_expected, qty_received")
      .in("gr_id", grIds);

    if (lineError) {
      return NextResponse.json(
        { ok: false, error: lineError.message },
        { status: 500 }
      );
    }

    const lineMap = new Map<string, { expected_total: number; received_total: number }>();
    ((lineRows || []) as GrLineRow[]).forEach((row) => {
      const prev = lineMap.get(row.gr_id) || { expected_total: 0, received_total: 0 };
      prev.expected_total += Number(row.qty_expected || 0);
      prev.received_total += Number(row.qty_received || 0);
      lineMap.set(row.gr_id, prev);
    });

    let asnMap = new Map<string, AsnHeaderRow>();
    if (asnIds.length > 0) {
      const { data: asnRows, error: asnError } = await sb
        .from("asn_header")
        .select("id, asn_no")
        .in("id", asnIds);

      if (asnError) {
        return NextResponse.json(
          { ok: false, error: asnError.message },
          { status: 500 }
        );
      }

      asnMap = new Map(((asnRows || []) as AsnHeaderRow[]).map((r) => [r.id, r]));
    }

    const items = headerRows.map((row) => {
      const agg = lineMap.get(row.id) || { expected_total: 0, received_total: 0 };
      const asn = row.asn_id ? asnMap.get(row.asn_id) : null;

      return {
        id: row.id,
        gr_no: row.gr_no,
        asn_id: row.asn_id,
        asn_no: asn?.asn_no || null,
        vendor_name: null,
        status: row.status,
        created_at: row.created_at,
        expected_total: agg.expected_total,
        received_total: agg.received_total,
      };
    });

    return NextResponse.json({ ok: true, items });
  } catch (e: any) {
    return NextResponse.json(
      { ok: false, error: e?.message || "Unknown error" },
      { status: 500 }
    );
  }
}