"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function VendorLoginPage() {
  const router = useRouter();
  const supabase = createClient();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setMessage("");

    try {
      const loginEmail = email.trim().toLowerCase();
      const loginPassword = password;

      const { data, error } = await supabase.auth.signInWithPassword({
        email: loginEmail,
        password: loginPassword,
      });

      console.log("LOGIN DATA:", data);
      console.log("LOGIN ERROR:", error);

      if (error) {
        throw new Error(error.message);
      }

      if (!data.session || !data.user) {
        throw new Error("Login succeeded but no session was returned");
      }

      setMessage("로그인 성공, 이동 중...");

      setTimeout(() => {
        router.push("/vendor/packing-lists");
        router.refresh();
      }, 300);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Login failed";
      console.error("VENDOR LOGIN FAILED:", err);
      setMessage(message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <div className="w-full max-w-md border rounded p-6 space-y-4">
        <div>
          <h1 className="text-2xl font-semibold">Vendor Login</h1>
          <p className="text-sm text-gray-500 mt-1">Vendor Portal 로그인</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-sm mb-1">Email</label>
            <input
              type="email"
              className="border rounded px-3 py-2 w-full"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="vendor.user@abc.com"
            />
          </div>

          <div>
            <label className="block text-sm mb-1">Password</label>
            <input
              type="password"
              className="border rounded px-3 py-2 w-full"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="password"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="border rounded px-4 py-2 w-full"
          >
            {loading ? "Signing in..." : "Login"}
          </button>
        </form>

        {message && <div className="text-sm text-red-600">{message}</div>}
      </div>
    </div>
  );
}