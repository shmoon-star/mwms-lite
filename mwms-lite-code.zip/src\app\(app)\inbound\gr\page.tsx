"use client";

import { useEffect, useMemo, useState } from "react";
import PageToolbar from "@/components/PageToolbar";
import CsvUploadButton from "@/components/CsvUploadButton";
import { downloadCsv } from "@/lib/csv";
import UploadTemplateCard from "@/components/upload/UploadTemplateCard";

type GRRow = {
  id: string;
  gr_no: string | null;
  status: string | null;
  asn_id: string | null;
  created_at: string | null;
  confirmed_at: string | null;
};

export default function GRPage() {
  const [rows, setRows] = useState<GRRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [keyword, setKeyword] = useState("");

  async function load() {
    try {
      setLoading(true);
      setError("");

      const res = await fetch("/api/gr", { cache: "no-store" });
      const text = await res.text();

      let json: any;
      try {
        json = JSON.parse(text);
      } catch {
        throw new Error(`Invalid JSON response: ${text}`);
      }

      if (!res.ok) {
        throw new Error(json?.error || "Failed to load GR");
      }

      const items = Array.isArray(json)
        ? json
        : json.items ?? json.data ?? json.grs ?? [];

      setRows(items);
    } catch (e: any) {
      setError(e?.message ?? "Unknown error");
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    const q = keyword.trim().toLowerCase();
    if (!q) return rows;

    return rows.filter((r) =>
      [r.gr_no, r.status, r.asn_id].some((v) =>
        String(v ?? "").toLowerCase().includes(q)
      )
    );
  }, [rows, keyword]);

  return (
    <div style={{ padding: 20 }}>
      <h2>Inbound / GR</h2>

      <GRUploadSection reload={load} />

      <PageToolbar
        onRefresh={load}
        onDownloadCsv={() =>
          downloadCsv(
            "gr.csv",
            filtered.map((r) => ({
              id: r.id,
              gr_no: r.gr_no,
              status: r.status,
              asn_id: r.asn_id,
              created_at: r.created_at,
              confirmed_at: r.confirmed_at,
            }))
          )
        }
      />

      <div style={{ marginBottom: 12 }}>
        <input
          placeholder="Search GR / Status / ASN..."
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          style={{
            width: 320,
            padding: 8,
            border: "1px solid #ccc",
            borderRadius: 4,
          }}
        />
      </div>

      <div style={{ marginBottom: 12, color: "#666" }}>
        Rows: {filtered.length}
      </div>

      {loading && <div>Loading...</div>}
      {error && <div style={{ color: "red", marginBottom: 12 }}>{error}</div>}

      {!loading && !error && filtered.length > 0 && (
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr>
              <th style={th}>GR No</th>
              <th style={th}>Status</th>
              <th style={th}>ASN ID</th>
              <th style={th}>Created At</th>
              <th style={th}>Confirmed At</th>
              <th style={th}>Action</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((r) => (
              <tr key={r.id}>
                <td style={td}>{r.gr_no ?? "-"}</td>
                <td style={td}>{r.status ?? "-"}</td>
                <td style={td}>{r.asn_id ?? "-"}</td>
                <td style={td}>{r.created_at ?? "-"}</td>
                <td style={td}>{r.confirmed_at ?? "-"}</td>
                <td style={td}>
                  <a href={`/inbound/gr/${r.id}`}>Open</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

function GRUploadSection({ reload }: { reload: () => void }) {
  return (
    <div className="upload-page-section">
      <UploadTemplateCard
        title="GR Bulk Upload"
        description="ASN No + Line No 기준 입고 수량 일괄 처리 템플릿"
        headers={["asn_no", "line_no", "sku", "qty_expected", "qty_received"]}
        sampleRows={[
          ["ASN-1773525278832", 1, "SKU001", 100, 100],
          ["ASN-1773525278832", 2, "SKU002", 50, 48],
        ]}
        onDownloadTemplate={() => window.open("/api/gr/template", "_blank")}
        uploadSlot={
          <CsvUploadButton uploadUrl="/api/gr/upload" onUploaded={reload} />
        }
      />
    </div>
  );
}

const th: React.CSSProperties = {
  border: "1px solid #ddd",
  padding: 8,
  background: "#f5f5f5",
  textAlign: "left",
};

const td: React.CSSProperties = {
  border: "1px solid #ddd",
  padding: 8,
};